import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		try{
			Scanner scanner = new Scanner(System.in);
			System.out.println("Birinci sayıyı giriniz:");
			int sayi1 = scanner.nextInt();
			System.out.println("İkinci sayıyı giriniz:");
			int sayi2 = scanner.nextInt();


			if(sayi1> sayi2){
				System.out.println("Birinci sayı ikinci sayıdan büyük olamaz.");
			}
			if(sayi1 == sayi2)
				System.out.println("Lütfen farklı sayı giriniz.");

			//negatif sayılar
			if(sayi1<0){
				System.out.println("Pozitif sayı giriniz");
				return;
			}
			if(sayi2<0){
				System.out.println("Pozitif sayı giriniz");
				return;
			}

			for(int i = sayi1 ;i<= sayi2;i++){
				if(i==0){
					i=2;
				}
				if(i==1){
					i=2;
				}
				boolean asal= true;
				for(int j =2;j<=i/2;j++)
					if(i%j == 0){
						asal = false;
						break;
					}
				if(asal)
					System.out.println(i+"\t");

			}
		}catch (Exception exception){
			System.out.println("Lütfen tam sayı giriniz.");
		}finally {
			System.out.println("Bitti.");
		}
	}
}